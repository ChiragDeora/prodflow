import RootAdminSetup from '@/components/setup/RootAdminSetup';

export default function SetupPage() {
  return <RootAdminSetup />;
}
