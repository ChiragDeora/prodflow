1. Master Data
	•	Machine Master
	•	Mold Master
	•	Raw Materials Master
	•	Packing Materials Master
	•	Line Master
	•	BOM Master
	•	Commercial Master
	•	Others



2. store Purchase
	•	Material Indent
	•	Purchase Order
	•	Open Indent
	•	History



3. store Inward
	•	Normal GRN
	•	JW Annexure GRN
	•	History



4. store Outward
	•	MIS
	•	Job Work Challan
	•	Delivery Challan
	•	History



5. store Sales
	•	Dispatch Memo
	•	Order Book
	•	History



6. Production Planner



7. Production
	•	Daily Production Report (DPR)
	•	Mold Loading & Unloading
	•	Silo Management / Grinding Records
	•	FG Transfer Note



8. Quality
	•	Quality Inspections
	•	Quality Standards
	•	Quality Analytics
	•	Daily Weight Report
	•	First Pieces Approval Report
	•	Corrective Action Plan
	•	R&D



9. Maintenance
	•	Preventive Maintenance
	•	Machine Breakdown
	•	Mold Breakdown
	•	History
	•	Daily Readings
	•	Report